package org.MyClient.src.application;

import java.io.IOException;

/**
 * 
 * @author 170011408
 *
 */
public class ClientMainClass {
	public static void main(String[] args) throws IOException {
		ClientFunctionalityClass client = new ClientFunctionalityClass();
	}
}
